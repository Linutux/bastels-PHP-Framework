<?php
$salt_add = md5(microtime());
$rounds = "08"; // how many rounds should we bcrypt?
$password = "123";
$email = "123@123.de";
/* Start - Creating fucking n1 bcrypt things */
$string = hash_hmac("whirlpool", str_pad($password, strlen($password)*4, sha1($email), STR_PAD_BOTH), $salt_add, true);
$salt = substr(str_shuffle('./0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ' ),0,22);
$pw_hash = crypt($string, '$2a$'.$rounds.'$'.$salt);
echo $pw_hash;
//$2a$08$w.kZtMEmvolhH7gIqQ2ra.puD12komAaxErVWygh5ZL/KPHU3Zud.
