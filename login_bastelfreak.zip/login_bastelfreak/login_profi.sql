-- phpMyAdmin SQL Dump
-- version 3.4.3.1
-- http://www.phpmyadmin.net
--
-- Host: mysql02.bastelfreak.org:3306
-- Erstellungszeit: 28. Jul 2011 um 10:28
-- Server Version: 5.1.49
-- PHP-Version: 5.3.3-7+squeeze3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `framework`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `login_profi`
--

CREATE TABLE IF NOT EXISTS `login_profi` (
  `id` mediumint(7) unsigned NOT NULL AUTO_INCREMENT,
  `benutzername` varchar(100) NOT NULL,
  `passwort` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `passwort_zusatz` varchar(32) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `benutzerinfo` varchar(255) NOT NULL,
  `anmeldung` varchar(32) NOT NULL,
  `zuletzt_aktiv` datetime NOT NULL,
  `fehlversuche` tinyint(2) unsigned NOT NULL,
  `aktiviert` tinyint(1) unsigned NOT NULL,
  `email` varchar(255) NOT NULL,
  `salt_rounds` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `benutzername` (`benutzername`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Daten für Tabelle `login_profi`
--

INSERT INTO `login_profi` (`id`, `benutzername`, `passwort`, `passwort_zusatz`, `ip`, `benutzerinfo`, `anmeldung`, `zuletzt_aktiv`, `fehlversuche`, `aktiviert`, `email`, `salt_rounds`) VALUES
(16, 'bastelfreak', '$2a$08$/MvIWtOVxA2QeoXKTz7j6.MRGv/pXkE1o//NJC8GeamQDrri3FNq2', '2f1ba0d473f303e19c79f7cc69ef5ef0', '83.216.237.253', 'Mozilla/5.0 (Windows NT 5.1; rv:5.0) Gecko/20100101 Firefox/5.0', '3dcfd4d30896c213f7f9667429a9450c', '2011-07-26 10:14:23', 0, 1, 'bastelfreak@bastelfreak.de', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
