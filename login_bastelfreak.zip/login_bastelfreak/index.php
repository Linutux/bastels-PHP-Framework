<?php
// something by bastelfreak, who knows...

// Erzwingen das Session-Cookies benutzt werden und die SID nicht per URL transportiert wird
ini_set( 'session.use_only_cookies', '1' );
ini_set( 'session.use_trans_sid', '0' );

// Session starten
session_start();

$debug = true;

/* Start - Errorhandling */
  if($debug === true){
    ini_set("display_errors", "on");
  }
  else{
    ini_set("display_errors", "off");
  }
  //set_error_handler("errorHandler");
  error_reporting(E_ALL);
  ini_set('error_reporting', E_ALL);
/* End - Errorhandling */

require("admincp/config.inc");
require("admincp/basement.inc");
require("int_res/login.inc");
//require("int_res/register.inc");
$Configuration = new Config;
$Praefix = $Configuration->Site_Praefix;
$Suffix = $Configuration->Site_Suffix;
$Basement = new basement;

if(!isset($_GET['site'])){	
	Header("Location: ?site=welcome");
}
elseif(file_exists($Praefix.$_GET["site"].$Suffix)){
	require($Praefix."head".$Suffix);
  require($Praefix.$_GET['site'].$Suffix);
  require($Praefix."footer".$Suffix);
	echo $Head;
	echo $Output;
	echo $Footer;
}	
	


?>