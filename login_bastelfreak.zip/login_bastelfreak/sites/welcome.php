<?php
$Login = new login;
if(isset($_GET["do"])){
	if($_GET["do"] == "logout"){
  resetUser();
	}
	elseif($_GET["do"] == "hello"){
		$Output = "Willkommen auf dieser porno Website<br>\n";
		if ($Login->checkUser()){
			$Output .= "Du bist gerade eingeloggt, gz...<br>\n";
			$Output .= "<a href='?site=welcome&do=logout'>ausloggn</a>\n";
			$Output .= "<a href='?site=rss'>RSS Features</a><br>\n";
		}else{
			$Output .= "<a href='?site=login'>einloggn</a><br>\n";
			$Output .= "<a href='?site=register'>registrieren</a><br>\n";
		}
	}
	elseif(empty($_GET["do"])){
		header("location: ?site=welcome&do=hello");
	}
}
else{
header("location: ?site=welcome&do=hello");
}


 ?>
