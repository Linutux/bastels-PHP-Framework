<?php
if(!empty($_POST)){
	$Login = new login;
	//$eingabe = CleanInput();
	/*if(!$Login->checkPassword($_POST["password"])){funktion muss noch �berarbeitet werden
		$Output = $FailMsg;
		exit;
	}*/
	/*if(!$Login->checkUsername($_POST["username"])){funktion muss noch �berarbeitet werden
		$Output = $FailMsg;
		exit;
	}*/ 
	require "/ext_res/email_verify_source.php";
	if(!validateEmail()$_POST["email"]){
		$Output = "Your eMailadress is invalid";
		exit;
	}
	if($Login->register($_POST['benutzer'], $_POST['email'], $_POST['password'], "08")){
		$Output = "Die Registrierung war erfolgreich<br>\n";
		$Output .= "<a href='?site=welcome&do=hello'>Hier geht es zur Startseite</a>\n";
	}
	else{
		echo $error;
	}
}
elseif(empty($_POST)){
	$Output = "<form id='loginform' method='post' action=''>\n";
	$Output .= "	<label for='username'>Benutzername: </label><input type='text' name='username' id='username' value='' /><br />\n";
	$Output .= "	<label for='password'>Passwort: </label><input type='password' name='password' id='password' value='' /><br />\n";
	$Output .= "	<label for='email'>eMailadresse: </label><input type='email' name='email' id='email' value='' /><br />\n";
	$Output .= "	<input type='submit' name='login' id='login' value='Anmelden' />\n";
	$Output .= "</form>\n";
}
?>

    
    
		
    
