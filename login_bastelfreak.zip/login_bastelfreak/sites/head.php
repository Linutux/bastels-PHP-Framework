<?php
$Head = "<!Doctype html>\n";
$Head .= "<html>\n";
$Head .= "<head>\n";
$Head .= "<title>Framework by bastelfreak</title>\n";
$Head .= "</head>\n";
$Head .= "<body>\n";
?>