<?php
$Footer = "</body>\n";
$Footer .= "</html>\n";
?>