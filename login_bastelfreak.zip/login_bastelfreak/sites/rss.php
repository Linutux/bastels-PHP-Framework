<?php
if(!isset($_GET["do"])){
	$Output = "Hier kannst du deinen eigenen personalisierten RSS Reader einrichten<br>\n";
	$Output .= "<a href='http://de.wikipedia.org/wiki/RSS'>RSS - Was ist das?<br>\n";
	$Output .= "<a href='&do=show_all'>Chronologische Anordnung aller eingerichteten Feeds</a><br>\n";
	$Output .= "<a href='&do=configure'>Eigene Feeds einstellen</a><br>\n";
	
}
elseif($_GET["do"] == "configure"){
	$Output = "Folgende Feeds sind schon abonierbar:<br>\n";
	// list of all feeds that are inside db(web_title)
	
	$Output = "Fehlt dein Lieblingsfeed in dieser Liste? Dann f&uuml;ge ihn selbst hinzu(einer pro Zeile):";
	$Output .= "<form id='loginform' method='post' action=''>\n";
	$Output .= "	<label for='username'>Benutzername: </label><input type='text' name='username' id='username' value='' /><br />\n";
	$Output .= "	<label for='password'>Passwort: </label><input type='password' name='password' id='password' value='' /><br />\n";
	$Output .= "	<label for='email'>eMailadresse: </label><input type='email' name='email' id='email' value='' /><br />\n";
	$Output .= "	<input type='submit' name='login' id='login' value='Anmelden' />\n";
	$Output .= "</form>\n";
}

















?>