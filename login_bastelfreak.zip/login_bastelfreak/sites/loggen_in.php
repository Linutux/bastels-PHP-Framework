<?php
if (checkUser(db_connect())){
  echo "du bist eingeloggt";
}
else{
  echo "nicht eigeloggt";
}

?>