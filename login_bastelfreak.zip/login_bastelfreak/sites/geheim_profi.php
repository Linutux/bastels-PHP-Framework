<?php

// Erzwingen das Session-Cookies benutzt werden und die SID nicht per URL transportiert wird
ini_set( 'session.use_only_cookies', '1' );
ini_set( 'session.use_trans_sid', '0' );

// Session starten
session_start();

// Funktionen einbinden
//require("int_res/login.inc");

// Datenbankverbindung öffnen
$conid = db_connect();

// Benutzer prüfen
if (!checkUser( $conid )){
	resetUser();
}

// Benutzer abmelden
if (!empty($_GET['benutzer']) && $_GET['benutzer'] == 'abmelden')
{
	resetUser();
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>phpBuddy.eu - Geheime Seite</title>
</head>
  <body>
    <h3>Willkommen im geschützten Bereich! ;-)</h3>
    <p>
      <a href="<?php echo "?benutzer=abmelden"; ?>">Benutzer abmelden</a>
    </p>
  </body>
</html>