<?php
// Sicherstellen das die SID durch den Server vergeben wurde
// um einen m�glichen Session Fixation Angriff unwirksam zu machen
if (!isset( $_SESSION['server_SID'] ))
{
	// M�glichen Session Inhalt l�schen
	session_unset();
	// Ganz sicher gehen das alle Inhalte der Session gel�scht sind
	$_SESSION = array();
	// Session zerst�ren
	session_destroy();
	// Session neu starten
	session_start();
	// Neue Server-generierte Session ID vergeben
	session_regenerate_id();
	// Status festhalten
	$_SESSION['server_SID'] = true;
}

// Variablen deklarieren
$_SESSION['angemeldet'] = false;
$anmeldung              = false;
$update                 = false;
$fehlermeldung          = '';

// Wenn das Formular abgeschickt wurde
if (isset($_POST['login'])){
	$Login = new login;
	// Benutzereingabe bereinigen
	//$eingabe = cleanInput();
	// Benutzer anmelden
	if(!$Login->checkPassword($_POST['passwort'])){
		$Output = $FailMsg;
	}
	else{
		$anmeldung = $Login->loginUser($_POST['benutzer'], $_POST['email'], $_POST['passwort']);
		// Anmeldung war korrekt
		if ($anmeldung)
		{
			// Benutzer Identifikationsmerkmale in DB speichern
			$update = $Login->updateUser($_POST['benutzer']);
			// Bei erfolgreicher Speicherung
			if ($update)
			{
				// Auf geheime Seite weiterleiten
				echo"<a href='?site=welcome'>Login erfolgreich, hier gehts zur Startseite</a>";
				//header( 'location: ?site=welcome' );
				exit;
			}
			else
			{
				$fehlermeldung = '<h3>Bei der Anmeldung ist ein Problem aufgetreten!</h3>';
			}
		}
		else
		{
			$fehlermeldung = '<h3>Die Anmeldung war fehlerhaft!</h3>';
		}
	}
	if ($fehlermeldung) echo $fehlermeldung;
}
else{
// Falls die Fehlermeldung gesetzt ist
$Output = "<form id='loginform' method='post' action=''>\n";
	$Output .= "	<label for='benutzer'>Benutzername: </label><input type='text' name='benutzer' id='benutzer' value='' /><br />\n";
	$Output .= "	<label for='passwort'>Passwort: </label><input type='password' name='passwort' id='passwort' value='' /><br />\n";
	$Output .= "	<label for='email'>eMailadresse: </label><input type='email' name='email' id='email' value='' /><br />\n";
	$Output .= "	<input type='submit' name='login' id='login' value='Anmelden' />\n";
	$Output .= "</form>\n";
}
?>
